import React from 'react'

const Compare = () => {
  return (
   <>
    <dir>
        <h1>Compare Page</h1>
    </dir>
   </>
  )
}

export default Compare
