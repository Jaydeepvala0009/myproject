import React from 'react';
import { Link } from 'react-router-dom';
import { Home1 } from "../Images/Img";
import { Homestyle } from "../Style/Style";



import { SiHonda,SiToyota,SiSuzuki,SiTata,SiKia,SiVolkswagen,SiAudi,SiMazda } from "react-icons/si";




const Home = () => {


      

  return (
   <>
    <Homestyle>
        <section className="container-fluid p-0">
            <div className="Main-home-page">
                <img src={Home1} alt="img" style={{width:"100%"}}/>
                <div className="Home-main-nav">
                    <nav className="navbar navbar-expand-lg navbar-light">
                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>

                        <div className="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul className="navbar-nav Home-icon-Gap">
                                <li className="nav-item">
                                    <Link className="nav-link Home-icon text-light" to="#">
                                        <SiHonda />
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <Link className="nav-link Home-icon text-light" to="#" >
                                        <SiToyota />
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <Link className="nav-link Home-icon text-light" to="#" >
                                        <SiSuzuki />
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <Link className="nav-link Home-icon text-light" to="#" >
                                        <SiTata />
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <Link className="nav-link Home-icon text-light" to="#" >
                                        <SiKia />
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <Link className="nav-link Home-icon text-light" to="#" >
                                        <SiMazda />
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <Link className="nav-link Home-icon text-light" to="#" >
                                        <SiAudi />
                                    </Link>
                                </li>
                                <li className="nav-item">
                                    <Link className="nav-link Home-icon text-light" to="#" >
                                        <SiVolkswagen />
                                    </Link>
                                </li>
                            </ul>
                        </div>
                    </nav>
    
                    <div className="Home-Content">
                        <h2 className="Border">HONDA&nbsp;</h2>
                        <h2>&nbsp;CS234</h2>
                    </div>

                    <div className="Home-buttons">
                        <button type="submit" className="Details-button">View Details</button>
                        <button type="submit" className="Details-button">Register Now</button>
                    </div>
                </div>
            </div>
        </section>
    </Homestyle>
   </>  
  )
}

export default Home
