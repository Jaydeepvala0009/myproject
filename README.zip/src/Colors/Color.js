

// _________ Project colors ___________//

const Colors = {

    TRANSPARENT: "transparent",
    BLACK:"#000000",
    WHITE:"#FFFFFF",
    BLUE:"#120ef0",
    RED:"#FF0000", 
    BORDER:"#FFFFFF",
    INPUT_BACKGROUND:"rgba(255, 255, 255, 0)",   
    LOGIN_BOXSHADOW:"rgba(0, 0, 0, 0.4)"
};
  
  export default Colors;
