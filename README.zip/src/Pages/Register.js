import React, {useState } from 'react';
import {Emailcontentimg, Emailicon, Error1 } from "../Images/Img";
import Loginfooter from '../Components/Loginfooter';
import { HiOutlineArrowNarrowRight , HiOutlineArrowNarrowLeft} from "react-icons/hi";
import Navbar1 from '../Components/Navbar1';
import { Registersubcomponent } from '../Style/Registercss';
import { HiCheck } from "react-icons/hi";
import usetranslation from '../React Localization/usetranslation';
import i18n from '../React Localization/i18';
import countryCode from '../Components/CountryCode.json'



const Register = () => {

  const t = usetranslation();
  const langDirection = i18n.language === "آر" ? "rtl" : "ltr";
  const lang = i18n.language === "آر";
   
  const [Fname, setFname] = useState("")
  const [Lname, setLname] = useState("")
  const [Email, setEmail] = useState("");
  const [Mnumber, setMnumber] = useState("");
  const [Password, setPassword] = useState("");
  const [Conpassword, setConpassword] = useState("");
  const [placeholder, setplaceholder] = useState('');
  const [check, setCheck] = useState(false);
  const [allData, setallData] = useState([]);
  const [error, setError] = useState("");
  const [Passtoglle, setPasstoglle] = useState(false);
  const [Compasstoglle, setCompasstoglle] = useState(false);


  const [selectedCountry, setSelectedCountry] = useState('');
  console.log('selectedCountry: ', selectedCountry);  
  const [countries, setCountries] = useState(countryCode.countries);


  
  const handleCountryChange = (e) => {
    const selectedCountryCode = e.target.value;
    console.log('target: ', e.target.value);
    setSelectedCountry(selectedCountryCode);
    
  };

  



  const onsubmit = (e) => {
    e.preventDefault();
    if (Password !== Conpassword){
      setError('Password Doesn’t Match');
    } else{
      setError("");
      const newentry = {Fname: Fname, Lname: Lname, Email: Email, Mnumber: Mnumber, Password: Password, Conpassword: Conpassword,}
      setallData([...allData, newentry]);
      dclear(); 
    }
  }

  const dclear = () => {
    setFname("");
    setLname("");
    setEmail("");
    setMnumber("");
    setPassword("");
    setConpassword("");
  }

  const checkhandle = () => {
    setCheck(!check);
  };
  const passtoglle = () => {
    setPasstoglle(!Passtoglle);
  }
  const compasstoglle = () => {
    setCompasstoglle(!Compasstoglle);
  }

  const isFormValid = (
    Fname !== '' &&
    Lname !== '' &&
    Email !== '' &&
    Mnumber !== '' &&
    Password !== '' &&
    Conpassword !== '' &&
    check
  )

  return (
    
    <>
      <Registersubcomponent>
        <section className="container-fluid p-0"  Dir ={langDirection}>
          <div className="Main-register-page">
          <Navbar1/>
              <section className="User-register">  
                <div className="Register-sub-Content">
                  <form className="Register-main-form" onSubmit={onsubmit} noValidate>
                    <div  className={lang ? "titlle-icon" : ""}>
                      {lang ? <HiOutlineArrowNarrowRight className="Fa-icoon"/> : <HiOutlineArrowNarrowLeft className="Fa-icoon"/>  }
                      <p className="lable-name">{t('title1')}</p>
                    </div>

                    <div className="Main-username">
                      <div className={`form-group mt-3 ${lang ? "langset" : ""}`}>
                        <input className="first-input" type="firstname" id="myInput" placeholder={placeholder} value={Fname} onChange={(e) => setFname(e.target.value)} />
                        <label htmlFor="myInput" className={lang ? "langset" : ""}>{t('Firstname')}</label>
                      </div>
                      <div className="form-group mt-3">
                        <input className="first-input" type="lastname" id="myInput" value={Lname} placeholder={placeholder} onChange={(e) => setLname(e.target.value)} />
                        <label htmlFor="myInput" className={lang ? "langset" : ""}>{t('Lastname')}</label>
                      </div>
                    </div>

                    <div className="form-group mt-2">
                      <input type="email" id="myInput" value={Email} placeholder={placeholder} onChange ={(e) => setEmail(e.target.value)}/>
                      <label htmlFor="myInput" className={lang ? "langset unique-label" : "unique-label"}>
                        {t('emailPlaceholder')}
                      </label>
                      <div className={`Email-icon ${lang ? "langset" : ""}`}>
                        <img src={Emailicon} alt="" className={lang ? "Email-Content-icon" : ""}/>
                        <div className="Tooltip-box">
                          <img src={Emailcontentimg} className="flipped-horizontal"  alt="" />
                          <p>{t("Emailcontent")}</p>
                        </div>
                      </div>
                    </div>
                    {/* <div className="Main-username">
                      <div className="form-group">
                        <select className="Fnumber-input mt-2">
                          <option>{t('Number1')}</option>
                          <option>{t('Number2')}</option>
                          <option>{t('Number3')}</option>
                        </select>
                      </div>
                      <div className="form-group Mnumber-start mt-2">
                        <input className="Snumber-input" type="Text" id="myInput" placeholder={placeholder} value={Mnumber} onChange ={(e) => setMnumber(e.target.value)}/>
                        <label htmlFor="myInput" className={`"Mnumber" ${lang ? "langset" : ""}`}>
                          {t('Mnumber')}
                        </label>  
                      </div>
                    </div>     
                  */}
                  

                  <div className="Main-username">
                    <div className="form-group">
                      <select className="Fnumber-input mt-2" onChange={handleCountryChange} value={selectedCountry}>
                        <option value="">+966</option>
                        {countries.map((country, index) => (
                          <option key={index} value={country.code}>
                            {`${t(country.name)} (${country.code})`}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="form-group Mnumber-start mt-2">
                      <input className="Snumber-input" type="text" id="myInput" placeholder={placeholder} value={Mnumber} onChange ={(e) => setMnumber(e.target.value)}/>
                      <label htmlFor="myInput" className={`"Mnumber" ${lang ? "langset" : ""}`}>
                        {t("emailPlaceholder")}
                      </label>
                    </div>
                  </div>

                 




                 


                    <div className="form-group mt-2">
                      <input type= {Passtoglle ? "text" : "Password"} id="myInput" value={Password} placeholder={placeholder} onChange={(e) => setPassword(e.target.value)}/>
                      <label htmlFor="myInput" className={lang ? "langset" : ""} >{t('passwordPlaceholder')}</label>   
                        <div className={`Password-show-hide ${lang ? "langset" : ""}`}>
                          <div>
                            {!Passtoglle ? <p onClick={passtoglle}>{t('Show')}</p> : <p onClick={passtoglle}>{t('Hide')}</p>}
                          </div>
                        </div> 
                    </div>
                    <div className="form-group mt-4">
                      <input className={error ? "Border" : ""} type={Compasstoglle ? "text" : "Password"} id="myInput" value={Conpassword} placeholder={placeholder} onChange={(e) => setConpassword(e.target.value)}/>
                      <label htmlFor="myInput" className={lang ? "langset unique-label" : "unique-label"}>
                        {t('CpasswordPlaceholder')}
                      </label>
                      <div className={`Password-show-hide ${lang ? "langset" : ""}`}>
                        <div>
                          {!Compasstoglle ? <p onClick={compasstoglle}>{t('Show')}</p> : <p onClick={compasstoglle}>{t('Hide')}</p>}
                        </div>
                      </div>

                      <div className="Password-error">
                        {error ? (
                          <div className="error-message">
                            <img src={Error1} className="error-img" alt="" />
                            <p>{error}</p>
                          </div>
                        ) : ("") }
                      </div>      
                    </div>
                    <div className="Main-check-Box">
                      <div className="Check-box" onClick={checkhandle}>
                        {check == true ? <HiCheck /> : ""}
                      </div>
                      <div className="check-box-text">
                          <p>{t('Discription')}</p>
                      </div>
                    </div>
                    <div className="register-btn">
                      <div className="register">
                        <button className={`register-Button ${isFormValid ? 'active' : ''}`} disabled={!isFormValid}>{t('CreateButtonText')}</button>
                      </div>
                    </div>
                  </form>        
                </div>  
              </section>
            <Loginfooter/>
          </div>
        </section>
      </Registersubcomponent>
    </>
  )
}
  export default Register;