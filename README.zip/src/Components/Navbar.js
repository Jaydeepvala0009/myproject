import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Navbarstyle, WrapperStyle } from '../Style/Style';
import {Navlogo1} from '../Images/Img.js';
import { HiMenu,HiMenuAlt1} from "react-icons/hi";
import Sidebar from "../Pages/Sidebar.js"; 


const Navbar = () => {

  const [togglesidebar, setTogglesidebar] = useState(false);

  const [faToggleonof, setfaToggleonof] = useState(false);

  const toggleSidebar = () => {
    setTogglesidebar(!togglesidebar);
  };
    
  const handlepass = () => {
    setfaToggleonof(!faToggleonof);
  };
  
  return (
    <>
      <Navbarstyle>
        <section className="container-fluid p-0">
          <main className="Nav-main">
            <WrapperStyle>
              <div>
                <nav className="navbar navbar-expand-lg navbar-light">
                  <Link className="navbar-brand" to="#">
                    <img src={Navlogo1} className="nav-logo" alt="" />
                  </Link>
                  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-1" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                      <span className="navbar-toggler-icon text-light" style={{fontSize:"10px"}}></span>
                  </button>
                  

                  <div className="collapse navbar-collapse" id="navbarSupportedContent-1">  
                    <ul className="navbar-nav ml-auto">
                      <li className="nav-item mr-4">
                          <Link className="nav-link text-light" to="">All CARS</Link>
                      </li>
                      <li className="nav-item mr-4">
                          <Link className="nav-link text-light" to="">HATCHBACK</Link>
                      </li>
                      <li className="nav-item mr-4">
                          <Link className="nav-link text-light" to="">SEDEN</Link>
                      </li>
                      <li className="nav-item mr-4">
                          <Link className="nav-link text-light" to="">SUV</Link>
                      </li>
                      <li className="nav-item mr-4">
                          <Link className="nav-link text-light" to="">PICK UPS</Link>
                      </li>
                      <li className="nav-item mr-4">
                          <Link className="nav-link text-light" to="">
                          EN

                          </Link>
                      </li>
                      <li className="nav-item mr-4">
                        <Link className="nav-link text-light" to="#" onClick={(toggleSidebar)}>
                          {faToggleonof == false ? <HiMenu onClick={handlepass} style={{fontSize:"25px"}}/> : <HiMenuAlt1 onClick={handlepass}  style={{fontSize:"25px"}}/>}
                        </Link>
                      </li>
                    </ul>
                  </div>
                </nav>
                {togglesidebar == true ? <Sidebar/> : null}
              </div>
            </WrapperStyle>
          </main>
        </section>
     </Navbarstyle>
    </>
  )
}

export default Navbar
