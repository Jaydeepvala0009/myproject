import React from 'react'

const ForgetPass = () => {
  return (
    <>
      <div>
        <h1>Forget password</h1>
      </div>
    </>
  )
}

export default ForgetPass
