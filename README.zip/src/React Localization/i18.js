import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  En: {
    translation: {
      title: 'Welcome!',
      title1: 'Create an Account',
      Firstname: 'First Name*',
      Lastname: 'First Name*',
      emailPlaceholder: 'Email*',
      passwordPlaceholder: 'Password*',
      CpasswordPlaceholder: 'Confirm Password*',
      Mnumber:'Mobile Number*',
      Number1:'+966',
      Number2:'+877',
      Number3:'+788',
      loginButtonText: 'Login',
      CreateButtonText: 'Create an Account',
      ForgetpasswordText: 'Forget Password ?',
      Discription:'By Creating a Watani account, I agree to the Terms of Use, and Privacy Notice.',
      Newuser: 'New User ?',
      Register: 'Register Now',
      Show: 'Show',
      Hide: 'Hide',
      About:'About Us',
      Tconditon:'Terms and Condition',
      Privacy: 'Privacy Policy',
      Help: 'Help',
      Careers: 'Careers',
      Cpolicy: 'Cancellation Policy',
      Emailcontent:"Email is used for communication purpose",

    },
  },
  
  آر: {
    translation: {
      title: 'أهلاً وسهلاً!',
      title1: 'إنشاء حساب',
      Firstname: 'الاسم الأول*',
      Lastname: 'اسم العائلة*',
      emailPlaceholder: 'بريد إلكتروني*',
      passwordPlaceholder: 'كلمة المرور*',
      CpasswordPlaceholder: 'تأكيد كلمة المرور*',
      Number1:'تسعة مائة وستة وستون+',
      Number2:'ثمانية مائة وسبعة وسبعو+',
      Number3:'سبعة مائة وثمانية وثمانون+',
      Mnumber:'رقم الهاتف المحمول*',
      loginButtonText: 'تسجيل الدخول',
      CreateButtonText: 'إنشاء حساب',
      ForgetpasswordText: 'نسيت كلمة المرور ?',
      Discription:'بإنشاء حساب وطني، فإنني أوافق على شروط الاستخدام وإشعار الخصوصية',
      Newuser: 'مستخدم جديد ?',
      Register: 'سجل الان',
      Show: 'يعرض',
      Hide: 'يخفي',
      About:'معلومات عنا',
      Tconditon:'أحكام وشروط',
      Privacy: 'سياسة الخصوصية',
      Help: 'يساعد',
      Careers: 'وظائف',
      Cpolicy: 'سياسة الإلغاء',
      Emailcontent:"يستخدم البريد الإلكتروني لغرض التواصل",

    },
  },
};

i18n.use(initReactI18next).init({
  resources,
  lng: 'En',
  fallbackLng: 'En',
  interpolation: {
    escapeValue: false,
  },
});

export default i18n;