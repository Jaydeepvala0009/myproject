
import styled from 'styled-components';
import Colors from '../Colors/Color';


export const WrapperStyle = styled.section`

    width: 90%;
    margin: 0 auto;
`;


// _____________Navbar Css Components____________

export const Navbarstyle = styled.section`  

    top: 0;
    width: 100%;
    z-index: 100;
    position: fixed;
    .navbar-nav {
        display: flex;
        justify-content: flex-end;
    }
    .Nav-main {
        background-image: 'linear-gradient(180deg, #000 0%, rgba(0, 0, 0, 0.40) 100%)';
    }
    .nav-logo{
        width:100%;

    }

    @media only screen and (max-width:1025px) {
        .navbar-brand, img{
            width:25%;
        }
    }
`;  

// ______________Login Page Css Components____________

export const Loginstyle = styled.section`
`;

export const Loginfooterstyle = styled.section`
    .Login-footer{
        width:100%;
        position: absolute;
        top:850px;
        display:grid;
        place-items: center;
    }
    .Main-footer-content {
        display: flex;
        list-style: none;
        gap:100px;
    }
    .Main-footer-content a {
        color: white;
    }
    .text-decoration {
        text-decoration: none;
    }
`;


// ______________UserLogin Compo... Css Components____________

export const Navbar1Style = styled.section`
    .Main-Navbar-content{
        width:100%;
        height: 80px;
        position:absolute;
        background-image: linear-gradient(180deg, rgba(255, 255, 255, 0.16) 0%, rgba(255, 255, 255, 0.00) 100%);
        box-shadow: 0px 12px 44px rgba(0, 10, 20, .3);
        backdrop-filter: blur(15);
    }
    .Wrapper{
        width: 90%;
        height: 80px;
        margin: 0 auto;
        display: flex;
        flex-direction: row;
        justify-content: center;
        align-items: center;
    }
    .Nav{
        width:100%;
        display:flex;
        justify-content: space-between;
    }
    .select-language {
        position: relative;
    }
    .language-dropdown {
        cursor: pointer;
    }
    .dropdown-content {
        width:85px;
        display: none;
        position: absolute;
        left: 0px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border: 1px solid #ccc;
        z-index: 1;
    }
    .language-dropdown:hover .dropdown-content {
        display: block;
        
    }
    .dropdown-content button {
        width:100%;
        display: block;
        padding: 10px;
        text-decoration: none;
        color: #FFFFFF;
        background-color: transparent;
        border: 1px solid ;
        border-color: ${Colors.WHITE};
    }
`;

export const Loginsubcomponent = styled.section`
    ${'' /* *{
        color: ${Colors.WHITE};
    }
    .Gradiant-color{
        width:100%;
        background: linear-gradient(243deg, rgba(0, 0, 0, 0.00) 0%, rgba(0, 0, 0, 0.50) 0.01%, rgba(0, 0, 0, 0.00) 100%);

    }
    .image-width{
        width:100%;
        background: linear-gradient(243deg, rgba(0, 0, 0, 0.00) 0%, rgba(0, 0, 0, 0.50) 0.01%, rgba(0, 0, 0, 0.00) 100%);
    }
    .Login-sub-Content {
        width: 450px;
        height: 560px;        
        position: absolute;
        top: 190px;
        left:58%;
        padding:25px;
        box-shadow: 0 0 10px ${Colors.LOGIN_BOXSHADOW};
        backdrop-filter: blur(20px);   
        
    }
    .lable-name{
        padding-top:20px;
        font-size: 32px;
        font-weight: 500;
        line-height: normal;
        letter-spacing: 0.59px;
    }
    .form-group, input{
        width: 400px;
        height:52px;
        font-size: 16px;
        outline:none;
        background: ${Colors.INPUT_BACKGROUND};
        border: 1px solid ${Colors.BORDER};
        caret-color: ${Colors.WHITE};
    }
    input:focus {
        border: 3px solid ;
        border-color: linear-gradient(180deg, rgba(255, 255, 255, 0.16) 0%, rgba(255, 255, 255, 0.04) 100%);
    }
    input::placeholder {
        padding:10px;
        color: ${Colors.WHITE}

    }
    .Forget-pass{
        margin-left:272px;
    }
    .Forget-pass a{
        text-decoration: none;
    }
    .btn-1{
        margin-top:80px;
    }
    .new-user a {
        text-decoration: none;
        color: ${Colors.WHITE};
    }
    .register-btn{
        margin-top:80px;
        display:flex;
        justify-content: center;
        align-item: center;
        gap:25px;
    }
    .register-Button{
        width:160px;
        height:44px;
        border:none;
        background: linear-gradient(180deg, rgba(255, 255, 255, 0.16) 0%, rgba(255, 255, 255, 0.04) 100%);
    } */}
    







${'' /*  
    .bordered-input::placeholder {
        color: white;
    }
    .Forget-pass{
        margin-left:61%;
    }
    .Button{
        display:flex;
        gap:35px;
    }
    .btn{
        width:45%;
        color: white;
        border: 1px solid;
        border-radius: 0px;

    } */}
`;


// ______________UserRegister Compo... Css Components____________

export const Registernsubcomponent = styled.section`
    .register-sub-Content{
        width: 30%;
        background-color: black;
        position: absolute;
        top:40%;
        left:60%;
        opacity:0.3;
        padding:20px;
    }
    .bordered-input{
        color: white;
        background-color: black;
        border: 1px solid;
        border-radius: 0px;
    }
    .bordered-input::placeholder {
        color: white;
    }
    .Name-Button, .input-size{
        width:100%;
        margin-top:10%;
        display:flex;
        gap:10%;
    }
    .num-1{
        width:65%;
        padding:0px
    }
    .form-group{
        width:100;
        padding-right:%;
    }
    .Forget-pass{
        margin-left:61%;
        padding:0px;
    }
    .Button{
        display:flex;
        gap:35px;
    }
    .btn{
        width:45%;
        color: white;
        border: 1px solid;
        border-radius: 0px;
    }
`;


// ______________Home Page  Css Components____________

export const Homestyle = styled.section`

    .Main-home-page {
        position: relative;
    }
    .Main-home-page img {
        width: 100%;
    }
    .Home-main-nav {
        width: 100%;
        height:70px;
        background-color: rgba(0, 0, 0, 0.5);   
        background: linear-gradient(180deg, #000 0%, rgba(0, 0, 0, 0.40) 100%);
        border-top: 2px solid white;
        position: absolute; 
        top: 65px;
        display:grid;
        place-items:center;
    }
    .navbar-nav{
        ${'' /* position:absolute; */}
    
       
    }
    .Home-Content{
        width:100%;
        margin-top:5%;
        color: white;
        justify-content: center;
            align-items: center;
        display:flex;
        flex-direction:row;
    }
    .Border{
        border-right: 2px solid white;
    }
    .Home-buttons{
        width:100%;
        height:40px;
        margin-top:32%;
        justify-content: center;
        align-item: center;
        display:flex;
        flex-direction:row;
    }
    .Details-button{
        width:12%;
        height:40px;
        color: white;
        background-color: rgba(0, 0, 0, 0.5);
        opacity:0.9;   
        border: 1.5px solid;
        border-radius: 0px;
        margin-right: 10px;
    }
    .Home-icon{
        font-size:30px;
        padding:0px;
    }
    .Home-icon-Gap{
        gap:10%;    
        margin-right:200px;
    }

    @media only screen and (max-width:1200px) {
        .Home-buttons{
            margin-top:22%;
        }
    }
    @media only screen and (max-width:907px) {
        .Details-button{
            width:15%;
        }
    }
    @media only screen and (max-width:750px) {
        .Home-buttons{
            margin-top:18%;
        }
        .Home-main-nav {
            height:50px;
        }
    }
    @media only screen and (max-width:907px) {
        .Details-button{
            width:20%;
        }
    }
    @media only screen and (max-width:425px) {
        .Home-Content, h2{
            font-size:15px;
            margin-top:1%;
        }
        .Details-button{
            width:30%;
            font-size:10px;

        }
        .Home-buttons{
            display:none;
        }
        .Home-main-nav {
            height:35px;
        }
    }

   
`;

// ______________Footer Compo.... Css Components___________

export const Footerstyle = styled.section`
    .Footer{
        width:100%;
        height:350px;
        background-color: rgba(24, 27, 32, 1);
    }
    .Footer-Main-Content{
        color: white ;
        justify-content: space-between;
        justify-content: center;
        align-item: center;
        gap:30px;
    }
    .Sub-1, .Sub-2, .Sub-3, .Sub-4{
        width:20%;
        margin-top:5%;
    }
    .Sub-4, .Gap {
        gap:20px;
    }
    .icon{
        font-size:25px;
    }
    .Rectangle{
        width:90%;
        height:1px;
        background-color: white;
    }
    .footer-bottem-content{
        color:white;
        margin-left:5%;
    }

    @media only screen and (max-width:1025px) {
        .Footer h6 {
            font-size: 10px;
        }
        .icon{
            font-size:15px;
        }
    }
`;

// ______________Sidebar Compo... Css Components____________

export const Sidebarstyle = styled.section`

    .sidebar-main-section{
        width:30%;
        height:550px;
        top:0;
        right:0px;
        margin-top:5.3%;
        position: fixed;
        color:white;
        transition: right 0.3s ease-in-out;
        background: linear-gradient(180deg, #000 0%, rgba(0, 0, 0, 0.40) 100%);
    }
    .sidebar-top-section{
        display:flex;
        justify-content:space-between;
        padding:20px;
    }
    .Sidebar-buttons{
        margin-top:40px;
        justify-content: center;
        align-item: center;
        display:flex;
        gap:10%;
    }
    button{
        width:35%;
        height:40px;
        color: white;
        background-color: rgba(0, 0, 0, 0.5);
        opacity:0.9;   
        border: 1.5px solid;
    }
    .Border{
        width:90%;
        height:0.5px;
        margin: 0 auto;
        background-color:white;
        opacity:0.3;

    }
`;


    