import React from 'react'
import { Link, useNavigate } from 'react-router-dom';
import { Sidebarstyle } from '../Style/Style';

import { FaCar } from "react-icons/fa";
import { ImBlogger2 } from "react-icons/im";
import { IoCall } from "react-icons/io5";
import { PiShoppingBagFill } from "react-icons/pi";
import { MdFindInPage } from "react-icons/md";


const Sidebar = () => {

    const navigate =useNavigate();

    const gotologin = () => {
        navigate("/Login");
    }

    const gotoregister = () => {
        navigate("/Register");
    }
    
    return (
        <>
            <Sidebarstyle>
                <section className="container-fluid p-0">
                    <div className="sidebar-main-section">
                        <div className="sidebar-top-section">
                            <h4>MENU</h4>
                        </div>

                        <div className="Border"></div>

                        <div className="Sidebar-buttons">
                            <button type="submit" onClick={gotologin}>LOGIN</button>
                            <button type="submit" onClick={gotoregister}>REGISTER</button>
                        </div>

                        <div className="Border mt-5"></div>

                        <div className="Sidebar-pages ml-3 mt-3">
                            <ul className="navbar-nav">
                                <li className="nav-item">
                                    <Link className="nav-link text-light mt-2" to="">
                                        <FaCar />  &nbsp;&nbsp;Compare
                                    </Link>
                                    <Link className="nav-link text-light mt-3" to="">
                                        <MdFindInPage />  &nbsp;&nbsp;Find Us
                                    </Link>
                                    <Link className="nav-link text-light mt-3" to="">
                                        <ImBlogger2 />&nbsp;&nbsp;Blog & Updates
                                    </Link>
                                    <Link className="nav-link text-light mt-3" to="">
                                        <PiShoppingBagFill />  &nbsp;&nbsp;Careers
                                    </Link>
                                    <Link className="nav-link text-light mt-3" to="">
                                        <IoCall />  &nbsp;&nbsp;Contact Us
                                    </Link>
                                </li>
                            </ul>
                        </div>
                    </div>
                </section>
            </Sidebarstyle>
        </>
    )
}

export default Sidebar
