import React from 'react';
import { Navbar1Style } from '../Style/Style';
import { Navlogo1 } from '../Images/Img';
import { IoIosArrowDown } from 'react-icons/io';
import { useDispatch, useSelector } from 'react-redux';
import { setLanguage, selectLanguage } from '../redux/LanguageSlice';
import i18 from '../React Localization/i18';



const Navbar1 = () => {

  const dispatch = useDispatch();
  const currentLanguage = useSelector(selectLanguage);

  const handleLanguageChange = (language) => {
    i18.changeLanguage(language);
    dispatch(setLanguage(language));
  };



  return (
    <>
      <Navbar1Style>
        <section className="Main-Navbar-content">
          <div className="Wrapper">
            <div className="Nav">
              <div className="logo">
                <img src={Navlogo1} alt="" />
              </div>
              <div className="select-language">
                <div className="language-dropdown">
                  <span>
                    {currentLanguage}
                    <IoIosArrowDown />
                  </span>
                  <div className="dropdown-content">
                    <button onClick={() => handleLanguageChange('En')}>English</button>
                    <button onClick={() => handleLanguageChange('آر')}>عربي</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </Navbar1Style>
    </>
  );
};

export default Navbar1;
