import React from 'react';
import { Link } from 'react-router-dom';
import { Loginfooterstyle } from "../Style/Style";
import usetranslation from '../React Localization/usetranslation';




const Loginfooter = () => {

const t = usetranslation();



  return (
  <>
     <Loginfooterstyle>
        <section className="container-fluid p-0">
          <div className="Login-footer">
            <div className="Main-footer-content">
              <div className="content-color">
                <Link to="#" className="text-decoration">{t('About')}</Link>
              </div>
              <div>
                <Link to="#" className="text-decoration">{t('Tconditon')}</Link>
              </div>
              <div>
                <Link to="#" className="text-decoration">{t('Privacy')}</Link>
              </div>
              <div>
                <Link to="#" className="text-decoration">{t('Help')}</Link>
              </div>
              <div>
                <Link to="#" className="text-decoration">{t('Careers')}</Link>
              </div>
              <div>
                <Link to="#" className="text-decoration">{t('Cpolicy')}</Link>
              </div>
            </div>
          </div>
        </section>
      </Loginfooterstyle>
  </>
  )
}

export default Loginfooter
