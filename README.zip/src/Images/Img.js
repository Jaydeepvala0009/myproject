
// _________ Project Images ___________//


import Bagroungimg1 from "../Allimages/navimg-1.jpg";
import Navlogo1 from "../Allimages/logo-1.png";
import Home1 from "../Allimages/Home-1.png";
import Error1 from "../Allimages/Error.png";
import Emailicon from "../Allimages/Email-icon.png";
import Emailcontentimg from "../Allimages/Emailcontentimg.svg";

export { Bagroungimg1, Navlogo1, Home1, Error1 , Emailicon, Emailcontentimg };
