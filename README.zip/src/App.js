import Login from './Pages/Login';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './Pages/Home';
import Navbar1 from './Components/Navbar1';
import Register from './Pages/Register';
import ForgetPass from './Auth/ForgetPass';
// import Navbar from './Components/Navbar';




function App() {


  return (
    <>
        <BrowserRouter>
          {/* <Navbar/> */}
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="Login" element={<Login />} />
              <Route path="Navbar1" element={<Navbar1 />} />
              <Route path="Register" element={<Register />} />
              <Route path="ForgetPass" element={<ForgetPass />} />
            </Routes>
          {/* <Footer/> */}
        </BrowserRouter> 
    </>
  );
}

export default App;
